# Step 1: Write user input to file
user = input("Enter text to write to the file: ")

try:
    with open("output.txt", "w") as fh:
        fh.write(user + "\n")
    print("Data successfully written to output.txt.")
except FileNotFoundError:
    print("Error: The file could not be found.")
except Exception as e:
    print("An error occurred while writing to the file:", e)


# Step 2: Append additional text
user1 = input("Enter additional text to append: ")

try:
    with open("output.txt", "a") as fh:
        fh.write(user1 + "\n")
    print("Data successfully appended.")
except FileNotFoundError:
    print("Error: The file could not be found.")
except Exception as e:
    print("An error occurred while appending to the file:", e)


# Step 3: Read and display the final content
print("\nFinal content of output.txt:")

try:
    with open("output.txt", "r") as fh:
        for line in fh:
            print(line.strip())
except FileNotFoundError:
    print("Error: The file 'output.txt' does not exist.")
except Exception as e:
    print("An error occurred while reading the file:", e)
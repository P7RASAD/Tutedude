# Step 1: Create and write to the file
try:
    with open("Task.txt", "w") as file:
        file.write("Line 1: This is a sample text file.\n")
        file.write("Line 2: It contains multiple lines.\n")
        file.write("Line 3: Python file handling example.\n")
    print("File created and written successfully!")

except Exception as e:
    print("Error while writing to the file:", e)


#
try:
    with open("Task.txt", "r") as file:
        print("\nReading file content line by line:")
        for line in file:
            print(line.strip())

except FileNotFoundError:
    print("Error: The file 'Task.txt' was not found.")

except Exception as e:
    print("An error occurred while reading the file:", e)
#as e → stores the error information in variable e